from qgis.core import *
from qgis.PyQt.QtCore import *
# from PyQt5.QtCore import *
# from PyQt5 import QtCore

from qgis.core.additions.edit import edit
#from QdivideFunctions import *
#import callCleanup
import pandas as pd
import LoadData
import QIN
from pathlib import Path

dfile=LoadData.getRawData('OK_data.xlsx',0)
print(Path.cwd())
file = open("E://myfile.txt","w")
L = ["This is Lagos \n","This is Python \n","This is Fcc \n"]

# i assigned ["This is Lagos \n","This is Python \n","This is Fcc \n"] to #variable L, you can use any letter or word of your choice.
# Variable are containers in which values can be stored.
# The \n is placed to indicate the end of the line.

file.write("Hello There \n")
file.writelines(L)
file.close()
TN=[]
RN=[]
SECT=[]
PK=[]


file = open("E://myfile.txt","w")
L = ["This is Lsssssssssssssssssssagos \n","This is Python \n","This is Fcc \n"]

# i assigned ["This is Lagos \n","This is Python \n","This is Fcc \n"] to #variable L, you can use any letter or word of your choice.
# Variable are containers in which values can be stored.
# The \n is placed to indicate the end of the line.

file.write("Hello There \n")
file.writelines(L)
file.close()

failureCount = 0

for index,r in dfile.iterrows():
  TN.append(r["TOWNSHIP"])
  RN.append(r["RANGE"])
  SECT.append(r["SECTION"])
  PK.append(r["CGA_UNIT"])


print('TotalTracts: ',str(len(TN)))


QIN.buildPLSSLayer(TN,RN,SECT,PK)

print("complete")