import pandas as pd
import xlrd
import openpyxl

def getRawData(filepath:str, skipRows):
    raw = pd.read_excel(filepath, dtype='object',skiprows=skipRows)
    return raw